SurferinWeb contains the following models:

	-DBGraph
	-SGraph which extends DBGraph
	-RandomSurfer
	-Server

Also contains:
	
	-serverdoc.dat which is used by SGraph to build the graph
	-RandomSurfer.MA which is needed to run the simulation
	-sessManagerTest.bat runs the simulation
	-Register, which is needed to form the coupled model
	-fileout.txt which is the file containing the output of
		the simulation

This coupled model simulates a Random Surfer which follows links 
and occasionnaly jumps to a random document

