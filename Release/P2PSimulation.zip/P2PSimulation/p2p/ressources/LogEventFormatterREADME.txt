Receives input from file named "fileout.txt" in the current 
directory. Then using that information, it generates a a file named
"SimuLogEvents" in the current directory

Note: The fileout.txt can only contain lines of the following format:


example:

00:01:11:083 publish 400000012

